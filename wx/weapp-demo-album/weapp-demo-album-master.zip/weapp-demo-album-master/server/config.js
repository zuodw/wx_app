module.exports = {
    port: '9993',
    ROUTE_BASE_PATH: '/applet',

    cosAppId: 'COS_APPID',
    cosSecretId: 'COS_SECRET_ID',
    cosSecretKey: 'COS_SECRET_KEY',
    cosFileBucket: 'album',
    cosUploadFolder: '/photos/',
};